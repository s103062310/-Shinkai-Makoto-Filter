# -Shinkai-Makoto-Filter

## Step1: median filtering
## Step2: color transform
## Step3: adjust
## Step4: paste sky
## Step5: add light
## Step6: sharpening

command >> final
執行一次完整流程
input: code中的src
所有input檔案都放在input/底下
改input只要更改code中imread的路徑檔名即可