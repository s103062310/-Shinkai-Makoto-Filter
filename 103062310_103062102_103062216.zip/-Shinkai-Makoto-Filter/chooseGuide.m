function [ out ] = chooseGuide( in, M, N )

    % Summary - auto choose guide

    % standard
    in = rgb2hsv(in);
    
    
    % choose guide
    
    out = zeros(M, N);
    if index==1
        out = im2double(imread('guide/guide1.jpg'));
    elseif index==2
        out = im2double(imread('guide/guide2.jpg'));
    elseif index==3
        out = im2double(imread('guide/guide3.jpg'));
    elseif index==4
        out = im2double(imread('guide/guide4.jpg'));
    elseif index==5
        out = im2double(imread('guide/guide5.jpg'));
    elseif index==6
        out = im2double(imread('guide/guide6.jpg'));
    elseif index==7
        out = im2double(imread('guide/guide7.jpg'));
    elseif index==8
        out = im2double(imread('guide/guide8.jpg'));
    elseif index==9
        out = im2double(imread('guide/guide9.jpg'));
    elseif index==10
        out = im2double(imread('guide/guide10.jpg'));
    elseif index==11
        out = im2double(imread('guide/guide11.jpg'));
    elseif index==12
        out = im2double(imread('guide/guide12.jpg'));
    end

end

